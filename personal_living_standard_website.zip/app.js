const YEARS = Array.from({ length: 13 }, (_, index) => 2014 + index);
const NO_CHOICE = "ללא בחירה";

const featureOptions = {
  "עשירון כלכלי": ["עשירונים 1-2", "עשירונים 3-5", "עשירונים 6-8", "עשירונים 9-10"],
  "מספר נפשות": ["1 נפש", "2 נפשות", "3-5 נפשות", "6+ נפשות"],
  "דת": ["יהודי", "נוצרי", "מוסלמי", "דרוזי", "אחר"],
  "מידת דתיות": ["חילוני", "מסורתי", "דתי", "חרדי", "אורח חיים מעורב/אחר"],
  "גיל מפרנס ראשי": ["עד 29", "30-39", "40-49", "50-59", "60-66", "67+"],
  "מרכזיות ישוב": ["מרכזי/מאוד מרכזי", "בינוני", "פריפריאלי/מאוד פריפריאלי"],
};

let appData = null;
let lastResult = null;

const el = (id) => document.getElementById(id);

function formatNumber(value) {
  return Number(value).toLocaleString("he-IL", { maximumFractionDigits: 1, minimumFractionDigits: 1 });
}

function setMessage(target, message, isError = false) {
  target.textContent = message;
  target.classList.toggle("error", isError);
}

function positiveNumber(value) {
  const num = Number(String(value).replaceAll(",", ""));
  if (!Number.isFinite(num) || num <= 0) {
    throw new Error("יש להזין מספר חיובי");
  }
  return num;
}

function positiveInteger(value) {
  const num = positiveNumber(value);
  if (!Number.isInteger(num)) {
    throw new Error("יש להזין מספר חיובי");
  }
  return num;
}

function standardPersons(count) {
  const scale = { 1: 1.25, 2: 2.0, 3: 2.65, 4: 3.2, 5: 3.75, 6: 4.25, 7: 4.75, 8: 5.2, 9: 5.6 };
  return scale[count] ?? 5.6 + (count - 9) * 0.4;
}

function classifyDecile(income, persons) {
  const incomePerStandard = income / standardPersons(persons);
  const match = appData.decileThresholds.find((row) => row.upper === null || incomePerStandard <= row.upper);
  return { decile: match.decile, group: match.group, incomePerStandard };
}

function buildFeatureControls() {
  const grid = el("featureGrid");
  grid.innerHTML = "";
  const choices = [...Object.keys(featureOptions), NO_CHOICE];
  for (let index = 0; index < 3; index += 1) {
    const card = document.createElement("div");
    card.className = "feature-card";
    card.innerHTML = `
      <strong>מאפיין ${index + 1}</strong>
      <select class="feature-select" aria-label="מאפיין ${index + 1}">
        ${choices.map((choice) => `<option value="${choice}" ${choice === NO_CHOICE ? "selected" : ""}>${choice}</option>`).join("")}
      </select>
      <small>בחר מהאפשרויות</small>
      <select class="value-select" aria-label="ערך מאפיין ${index + 1}" disabled></select>
    `;
    grid.appendChild(card);
  }

  document.querySelectorAll(".feature-select").forEach((select) => {
    select.addEventListener("change", () => refreshValueSelect(select));
    refreshValueSelect(select);
  });
}

function refreshValueSelect(featureSelect) {
  const card = featureSelect.closest(".feature-card");
  const valueSelect = card.querySelector(".value-select");
  const feature = featureSelect.value;
  if (feature === NO_CHOICE) {
    valueSelect.innerHTML = "";
    valueSelect.disabled = true;
    return;
  }
  valueSelect.disabled = false;
  valueSelect.innerHTML = featureOptions[feature].map((value) => `<option value="${value}">${value}</option>`).join("");
}

function selectedFilters() {
  const filters = {};
  const features = Array.from(document.querySelectorAll(".feature-select")).map((select) => select.value);
  const realFeatures = features.filter((feature) => feature !== NO_CHOICE);
  if (realFeatures.length === 0) {
    throw new Error("לא נבחרו מאפייני קבוצה");
  }
  if (new Set(realFeatures).size !== realFeatures.length) {
    throw new Error("לא ניתן לבחור את אותו מאפיין יותר מפעם אחת");
  }

  document.querySelectorAll(".feature-card").forEach((card) => {
    const feature = card.querySelector(".feature-select").value;
    const value = card.querySelector(".value-select").value;
    if (feature !== NO_CHOICE) {
      filters[feature] = value;
    }
  });
  return filters;
}

function personaId(filters) {
  return Object.keys(featureOptions)
    .filter((feature) => Object.prototype.hasOwnProperty.call(filters, feature))
    .map((feature) => `${feature}=${filters[feature]}`)
    .join("|");
}

function calculatePersona(filters) {
  const id = personaId(filters);
  const persona = appData.personas[id];
  if (!persona) {
    throw new Error("לא נמצאו מספיק נתונים עבור קבוצת המאפיינים שנבחרה. נסו לבחור פחות מאפיינים או מאפיין אחר.");
  }
  return {
    filters: persona.filters,
    annual: persona.annual,
    strongest: [persona.strongest, persona.strongestContribution],
  };
}

function drawChart(canvas, rows, key, color) {
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || canvas.width;
  const height = Math.max(260, Math.round(width * 0.42));
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, width, height);

  const values = rows.map((row) => row[key]);
  const min = Math.min(...values) - 5;
  const max = Math.max(...values) + 5;
  const pad = { top: 28, right: 42, bottom: 50, left: 28 };
  const x = (index) => pad.right + (index * (width - pad.right - pad.left)) / (rows.length - 1);
  const y = (value) => pad.top + ((max - value) * (height - pad.top - pad.bottom)) / (max - min);

  ctx.strokeStyle = "#d4e1de";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(pad.right, pad.top);
  ctx.lineTo(pad.right, height - pad.bottom);
  ctx.lineTo(width - pad.left, height - pad.bottom);
  ctx.stroke();

  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.beginPath();
  rows.forEach((row, index) => {
    const px = x(index);
    const py = y(row[key]);
    if (index === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  });
  ctx.stroke();

  ctx.font = "12px Arial";
  ctx.textAlign = "center";
  ctx.fillStyle = "#16333a";
  rows.forEach((row, index) => {
    const px = x(index);
    const py = y(row[key]);
    ctx.beginPath();
    ctx.fillStyle = "#ffffff";
    ctx.arc(px, py, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = color;
    ctx.stroke();
    ctx.fillStyle = "#16333a";
    ctx.fillText(formatNumber(row[key]), px, py + 20);
    if (index % 2 === 0 || width > 720) {
      ctx.fillText(row.year, px, height - 22);
    }
  });
}

function renderResults(result) {
  lastResult = result;
  el("resultsPanel").classList.remove("hidden");
  el("selectedSummary").textContent = Object.entries(result.filters).map(([feature, value]) => `${feature}: ${value}`).join(" | ");
  el("influenceLine").textContent = `סעיף ההוצאות שהכי השפיע עליך הוא: ${result.strongest[0]} (${formatNumber(result.strongest[1])} נקודות אחוז תרומה מצטברת בקירוב)`;

  const table = el("resultsTable");
  table.innerHTML = `
    <thead><tr><th>שנה</th><th>מדד כוח קניה 2014=100</th><th>מדד מחירים אישי 2014=100</th></tr></thead>
    <tbody>
      ${result.annual
        .map((row) => `<tr><td>${row.year}</td><td>${formatNumber(row.powerIndex)}</td><td>${formatNumber(row.priceIndex)}</td></tr>`)
        .join("")}
    </tbody>
  `;
  drawChart(el("powerChart"), result.annual, "powerIndex", "#1f8a55");
  drawChart(el("priceChart"), result.annual, "priceIndex", "#24566a");
  el("resultsPanel").scrollIntoView({ behavior: "smooth", block: "start" });
}

function downloadWorkbook() {
  if (!lastResult) return;
  const rows = [
    ["מדד כוח הקניה לקבוצה:"],
    ...Object.entries(lastResult.filters),
    [],
    ["שנה", "מדד כוח קניה 2014=100", "מדד מחירים אישי 2014=100"],
    ...lastResult.annual.map((row) => [row.year, Number(row.powerIndex.toFixed(1)), Number(row.priceIndex.toFixed(1))]),
    [],
    ["סעיף ההוצאות שהכי השפיע עליך הוא:", lastResult.strongest[0], Number(lastResult.strongest[1].toFixed(1)), "נקודות אחוז תרומה מצטברת בקירוב"],
    [],
    ["הערה", "בשנים 2024-2026 אין בטבלה מיקרו-דאטה חדש של משקי בית; הרכב הצריכה מחושב לפי השנה האחרונה שבה היו נתונים לקבוצה שלכם, ועליית השכר לפי העלייה הכללית במשק."],
  ];
  const methodology = [
    ["שנת בסיס", "2014=100"],
    ["חישוב מחירים", "סכום משוקלל של שינוי מחיר בכל סעיף לפי אחוז הצריכה הממוצע של הקבוצה."],
    ["חישוב כוח קניה", "מדד קודם × (1+שינוי הכנסה/שכר) / (1+עליית מחירים אישית)."],
    ["שנים חסרות", "הרכב צריכה: מילוי קדימה/אחורה לפי התצפית הקרובה. הכנסה: אינטרפולציה לינארית בין תצפיות ידועות; בקצוות שינוי כללי במשק."],
    ["ספי עשירונים", "למ״ס לוח 2, הכנסה נטו לנפש סטנדרטית: https://www.cbs.gov.il/he/publications/DocLib/2026/1994/ta2.xlsx"],
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(rows);
  const ms = XLSX.utils.aoa_to_sheet(methodology);
  ws["!cols"] = [{ wch: 16 }, { wch: 28 }, { wch: 28 }, { wch: 42 }];
  ms["!cols"] = [{ wch: 24 }, { wch: 120 }];
  XLSX.utils.book_append_sheet(wb, ws, "תוצאות");
  XLSX.utils.book_append_sheet(wb, ms, "מקורות ומתודולוגיה");
  XLSX.writeFile(wb, `מדד_כוח_קניה_פרסונה_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

async function init() {
  try {
    const response = await fetch("data/persona-results-data.json");
    if (!response.ok) throw new Error("לא הצלחתי לטעון את קובץ הנתונים של האתר.");
    appData = await response.json();
    buildFeatureControls();
  } catch (error) {
    setMessage(el("personaResult"), error.message, true);
    return;
  }

  el("decileButton").addEventListener("click", () => {
    try {
      if (!el("incomeInput").value || !el("personsInput").value) {
        throw new Error("יש למלא את כל השדות");
      }
      const income = positiveNumber(el("incomeInput").value);
      const persons = positiveInteger(el("personsInput").value);
      const result = classifyDecile(income, persons);
      setMessage(
        el("decileResult"),
        `אתם בעשירון ${result.decile} וקבוצת העשירונים שמתאימה לכם היא קבוצת ${result.group}\nהכנסה חודשית נטו לנפש תקנית: ${formatNumber(result.incomePerStandard)} ש״ח`
      );
    } catch (error) {
      setMessage(el("decileResult"), error.message, true);
    }
  });

  el("personaButton").addEventListener("click", () => {
    try {
      const filters = selectedFilters();
      const result = calculatePersona(filters);
      renderResults(result);
      setMessage(el("personaResult"), "החישוב הושלם. אפשר להוריד את קובץ האקסל בתחתית התוצאות.");
    } catch (error) {
      setMessage(el("personaResult"), error.message, true);
    }
  });

  el("downloadButton").addEventListener("click", downloadWorkbook);
  window.addEventListener("resize", () => {
    if (lastResult) renderResults(lastResult);
  });
}

init();
